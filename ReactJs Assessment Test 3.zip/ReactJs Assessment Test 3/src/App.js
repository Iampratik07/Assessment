import React, { useState } from "react";

const Accordion = ({ title, content }) => {
  const [isOpen, setIsOpen] = useState(false);

  const toggleAccordion = () => {
    setIsOpen(!isOpen);
  };

  return (
    <div className="accordion">
      <div className="accordion-header" onClick={toggleAccordion}>
        {title}
      </div>
      {isOpen && <div className="accordion-body">{content}</div>}
    </div>
  );
};

const App = () => {
  return (
    <div>
      <Accordion title="Accordion 1" content="Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptate aspernatur veritatis eligendi a doloremque, dolores praesentium culpa nostrum quaerat dolor." />
      <Accordion title="Accordion 2" content="Lorem ipsum dolor sit amet consectetur adipisicing elit. A natus omnis quidem ratione tempore eveniet ad deserunt excepturi molestias libero dicta cupiditate ea corporis, magni dolor quod error quibusdam, quam aspernatur, eum possimus! Consequuntur repellat facere, exercitationem possimus labore consequatur doloremque nemo, voluptatum laudantium magni aspernatur pariatur officiis ducimus animi ipsum molestiae obcaecati tempore molestias veniam inventore qui sequi dolores ab aut. Accusamus ea id ipsam laborum omnis iusto sequi laboriosam! Ipsa veritatis aliquid id fuga? Illum porro sit commodi error atque vitae perspiciatis voluptatum veritatis sint ratione debitis sequi mollitia labore tenetur, eius distinctio laborum impedit a doloremque. Perspiciatis?" />
      <Accordion title="Accordion 3" content="Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repellendus esse est voluptates beatae impedit magni nesciunt consequuntur quod iusto facilis. Reprehenderit rem suscipit cum perferendis illum itaque quasi recusandae hic quaerat, nulla eius dolor incidunt cumque maiores pariatur expedita? Magnam tempore amet fuga voluptas aut culpa error ad deserunt exercitationem ratione quidem nihil quo blanditiis minima, eligendi sunt, minus delectus sapiente, aliquam esse iusto voluptatum assumenda mollitia? Reiciendis quae excepturi sit iusto aliquam esse repudiandae, rerum mollitia aliquid aspernatur non tempora fugiat, autem, veniam quod vel quam! Beatae dignissimos quisquam, debitis laboriosam alias, cupiditate error assumenda tempore officia asperiores amet libero ea consequatur veritatis quo dicta odio? Blanditiis qui sequi dolore fugit. Veritatis porro odit doloribus in commodi quas ipsa possimus provident ullam ad repudiandae, aliquam repellat architecto voluptatibus sed. Saepe reiciendis voluptatem labore natus deleniti ab vero iure laborum a voluptas? Earum velit, quis rem mollitia ea ratione consequuntur." />
    </div>
  );
};

export default App;